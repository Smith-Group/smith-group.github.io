## ---- include = FALSE-------------------------------------------------------------------
knitr::opts_knit$set(
  global.par = TRUE
)
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  cache = TRUE,
  fig.retina = 2
)
#knitr::opts_chunk$set(optipng = "-o7 -strip all")
#knitr::knit_hooks$set(optipng = knitr::hook_optipng)
options(digits=5, width=90)

## ----setup------------------------------------------------------------------------------
library(fitnmr)

## ---------------------------------------------------------------------------------------
t1_dir <- system.file("extdata", "t1", package="fitnmr")
t1_ft2_filenames <- list.files(t1_dir, pattern=".ft2")
t1_ft2_filenames

## ---------------------------------------------------------------------------------------
spec_list <- lapply(file.path(t1_dir, t1_ft2_filenames), read_nmrpipe, dim_order="hx")
names(spec_list) <- t1_ft2_filenames

## ---------------------------------------------------------------------------------------
str(spec_list)

## ---- include = FALSE-------------------------------------------------------------------
par(mar=c(3, 3, 1, 1), mgp=c(2, 0.8, 0))

## ---- fig.height = 7, fig.width = 7, fig.align = "left"---------------------------------
contour_pipe(spec_list[[1]]$int)

## ---- include = FALSE-------------------------------------------------------------------
par(mar=c(3, 1, 1, 1), mgp=c(2, 0.8, 0))

## ----noise, fig.height = 2, fig.width = 3, fig.show = "hide"----------------------------
noise_mat <- sapply(spec_list, function(x) noise_estimate(x$int))
noise_mat

## ---- echo = FALSE, hold = TRUE---------------------------------------------------------
knitr::include_graphics(sprintf("%snoise-%i.png", knitr::opts_current$get("fig.path"), c(1,2)))

## ---- include = FALSE-------------------------------------------------------------------
par(mar=c(3, 3, 1, 1), mgp=c(2, 0.8, 0))

## ---- fig.height = 7, fig.width = 7, fig.align = "left"---------------------------------
peak_fits <- fit_peak_iter(spec_list[1], iter_max=3)
peak_df <- param_list_to_peak_df(peak_fits)
peak_df
plot_peak_df(peak_df, spec_list[1], cex=0.6)

## ---- include = FALSE-------------------------------------------------------------------
par(mar=c(3, 3, 2, 1), mgp=c(2, 0.8, 0))

## ---- fig.height = 3, fig.width = 4, fig.align = "left"---------------------------------
peak_fits <- fit_peak_iter(spec_list[1], iter_max=1, fit_list=peak_fits, plot_fit_stages=TRUE)

## ---- include = FALSE-------------------------------------------------------------------
par(mar=c(3, 3, 1, 1), mgp=c(2, 0.8, 0))

## ---- fig.height = 6, fig.width = 6, fig.align = "left"---------------------------------
plot_peak_df(param_list_to_peak_df(peak_fits), spec_list[1], cex=0.6)
rect(8.41, 120.6, 8.31, 119.2, border="green")
text(8.31, 119.9, "New Cluster", pos=4, col="green")

## ---- fig.height = 7, fig.width = 7, fig.align = "left"---------------------------------
peak_fits <- fit_peak_iter(spec_list[1], fit_list=peak_fits)
peak_df <- param_list_to_peak_df(peak_fits)
peak_df
plot_peak_df(peak_df, spec_list[1], cex=0.6)

## ---- fig.height = 7, fig.width = 7, results = "hide"-----------------------------------
peak_fits_no_sc <- fit_peak_iter(spec_list[1], sc_start=c(NA, NA))
plot_peak_df(param_list_to_peak_df(peak_fits_no_sc), spec_list[1], cex=0.6)
rect(8.55, 122.8, 8.43, 122.1, border="green")
text(8.43, 122.5, "Coupling\nDetected\nde novo", pos=4, col="green")

## ----separate---------------------------------------------------------------------------
edited_peak_df <- peak_df
edited_peak_df[c(5,7),"fit"] <- max(edited_peak_df[,"fit"])+1

## ----delete-----------------------------------------------------------------------------
edited_peak_df <- edited_peak_df[-c(4,14,16),]

## ---- include = FALSE-------------------------------------------------------------------
par(mar=c(3, 3, 1, 1), mgp=c(2, 0.8, 0))

## ----refine, fig.height = 7, fig.width = 7, fig.align = "left"--------------------------
refined_fit_input <- peak_df_to_fit_input(edited_peak_df, spec_list[1], omega0_plus=c(0.075, 0.75))
refined_fit_input <- update_fit_bounds(refined_fit_input, omega0_r2_factor=1.5, r2_bounds=c(0.5, 20), sc_bounds=c(2, 12))
refined_fit_output <- perform_fit(refined_fit_input)
refined_peak_df <- param_list_to_peak_df(refined_fit_output)
refined_peak_df
plot_peak_df(refined_peak_df, spec_list[1], cex=0.6)

## ---------------------------------------------------------------------------------------
extended_fit_input <- peak_df_to_fit_input(refined_peak_df, spec_list, omega0_plus=c(0.075, 0.75))

## ---- include = FALSE-------------------------------------------------------------------
par(mar=c(3, 3, 1, 1), mgp=c(2, 0.8, 0))

## ----extend, fig.height = 7, fig.width = 7, fig.show = "hide"---------------------------
head(refined_fit_output$fit_list$m0)
head(extended_fit_input$start_list$m0)
extended_fit_input <- update_fit_bounds(extended_fit_input, omega0_r2_factor=1.5, r2_bounds=c(0.5, 20), sc_bounds=c(2, 12))
extended_fit_output <- perform_fit(extended_fit_input)
extended_peak_df <- param_list_to_peak_df(extended_fit_output)
extended_peak_df
plot_peak_df(extended_peak_df, spec_list, cex=0.6)

## ---- echo = FALSE, fig.show = "hold"---------------------------------------------------
knitr::include_graphics(sprintf("%sextend-1.png", knitr::opts_current$get("fig.path")))

## ---- echo = FALSE, fig.show = "hold"---------------------------------------------------
knitr::include_graphics(sprintf("%sextend-2.png", knitr::opts_current$get("fig.path")))

## ---- include = FALSE-------------------------------------------------------------------
par(mar=c(3, 3, 1, 1), mgp=c(2, 0.8, 0))

## ---- fig.height = 4, fig.width = 4-----------------------------------------------------
xlim <- range(0, extended_peak_df[,"1.ft2"])
ylim <- range(0, extended_peak_df[,"2.ft2"])
plot(extended_peak_df[,c("1.ft2", "2.ft2")], xlim=xlim, ylim=ylim)
abline(lsfit(extended_peak_df[,"1.ft2"], extended_peak_df[,"2.ft2"]), col="red")
plot(extended_peak_df[,"2.ft2"]/extended_peak_df[,"1.ft2"], xlab="Peak Number", ylab="Spectrum 2 Volume/Spectrum 1 Volume")

